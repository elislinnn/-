import sys, json
import numpy as np, pandas as pd
from scipy import stats

PATH = sys.argv[1]
x = pd.read_excel(PATH, sheet_name=None)
u_raw, p_raw = x['Пользователи'].copy(), x['Платежи'].copy()
S = ['step1_opened', 'step2_entered', 'step3_confirmed', 'step4_success']
R = {}

# ---------- cleaning ----------
log = []
u = u_raw.copy()
bad_u = u[(u.group.isna()) | (u.city.isna()) | (~u.age.between(14, 100)) | (u.user_id > 2500)]
for _, r in bad_u.iterrows():
    reasons = []
    if pd.isna(r.group): reasons.append('нет группы')
    if pd.isna(r.city): reasons.append('нет города')
    if not 14 <= r.age <= 100: reasons.append(f'возраст {r.age}')
    if r.user_id > 2500: reasons.append('ID вне диапазона 1001–2500')
    log.append(dict(table='Пользователи', id=int(r.user_id), reason='; '.join(reasons)))
u = u.drop(bad_u.index)

p = p_raw.copy()
m = p.merge(u_raw[['user_id', 'group']], on='user_id', how='left', suffixes=('', '_u'))
bad_p_mask = (p.user_id.isna()) | (~p.user_id.isin(u.user_id)) | (p.payment_id > 9000) | \
             ((m.group != m.group_u) & m.group_u.notna()).values
for _, r in p[bad_p_mask].iterrows():
    reasons = []
    if pd.isna(r.user_id): reasons.append('пустой user_id')
    elif not (u.user_id == r.user_id).any(): reasons.append(f'клиент {int(r.user_id)} исключён как тестовый')
    if r.payment_id > 9000: reasons.append('payment_id вне диапазона 5001–7658')
    g = u_raw.loc[u_raw.user_id == r.user_id, 'group']
    if len(g) and g.iloc[0] != r.group: reasons.append(f'группа платежа {r.group} ≠ группе клиента {g.iloc[0]}')
    log.append(dict(table='Платежи', id=int(r.payment_id), reason='; '.join(reasons)))
p = p[~bad_p_mask].copy()

# sanity checks on the clean data
chk = {}
chk['period_ok'] = bool(p.step1_opened.between('2024-04-01', '2024-05-01').all())
chk['order_violations'] = int(sum(((p[b] - p[a]).dt.total_seconds() < 0).sum() for a, b in zip(S, S[1:])))
chk['skipped_steps'] = int(sum((p[S[j]].notna() & p[S[i]].isna()).sum() for i in range(4) for j in range(i + 1, 4)))
chk['dup_rows'] = int(p.drop(columns='payment_id').duplicated().sum())
dur = {}
for a, b in zip(S, S[1:]):
    d = (p[b] - p[a]).dt.total_seconds() / 60
    q1, q3 = d.quantile([.25, .75]); iqr = q3 - q1
    dur[f'{a}->{b}'] = dict(min=float(d.min()), max=float(d.max()), median=float(d.median()),
                            iqr_outliers=int(((d > q3 + 3 * iqr) | (d < q1 - 3 * iqr)).sum()))
chk['durations'] = dur
R['log'] = log; R['checks'] = chk
R['raw'] = dict(users=len(u_raw), payments=len(p_raw))
R['clean'] = dict(users=len(u), payments=len(p))

p['g'] = p.group
for i, s in enumerate(S): p[f'r{i+1}'] = p[s].notna().astype(int)
p = p.merge(u[['user_id', 'device_type', 'city', 'age']], on='user_id')

# ---------- EDA ----------
R['users_by_group'] = u.group.value_counts().sort_index().to_dict()
srm = stats.chisquare(u.group.value_counts().values)
R['srm_p'] = float(srm.pvalue)
bal = {}
for c in ['device_type', 'city']:
    ct = pd.crosstab(u[c], u.group)
    bal[c] = dict(table=(ct / ct.sum()).round(4).to_dict(), p=float(stats.chi2_contingency(ct)[1]))
bal['age'] = dict(mean={g: float(u[u.group == g].age.mean()) for g in 'AB'},
                  p=float(stats.mannwhitneyu(u[u.group == 'A'].age, u[u.group == 'B'].age).pvalue))
R['balance'] = bal
R['age_stats'] = u.age.describe().round(2).to_dict()

uu = p.groupby(['user_id', 'g']).agg(n=('r1', 'size'), s=('r4', 'sum')).reset_index()
uu = u[['user_id', 'group', 'device_type', 'city', 'age']].merge(uu, on='user_id', how='left').fillna({'n': 0, 's': 0})
R['users_without_payments'] = int((uu.n == 0).sum())
R['attempts_per_user'] = {g: float(uu[uu.group == g].n.mean()) for g in 'AB'}
R['attempts_mw_p'] = float(stats.mannwhitneyu(uu[uu.group == 'A'].n, uu[uu.group == 'B'].n).pvalue)
R['attempts_dist'] = {g: uu[uu.group == g].n.value_counts().sort_index().astype(int).to_dict() for g in 'AB'}

# funnel
fun = {}
for g in 'AB':
    d = p[p.g == g]
    c = [int(d[f'r{i}'].sum()) for i in range(1, 5)]
    fun[g] = dict(counts=c, step_conv=[c[i + 1] / c[i] for i in range(3)], total=c[3] / c[0])
R['funnel'] = fun

# ---------- statistics ----------
def delta_ratio(num, den):
    """mean ratio sum(num)/sum(den) with delta-method variance (user = cluster)."""
    n = len(num); mx, my = den.mean(), num.mean()
    vx, vy, cxy = den.var(ddof=1), num.var(ddof=1), np.cov(num, den, ddof=1)[0, 1]
    r = my / mx
    var = (vy / mx**2 - 2 * my * cxy / mx**3 + my**2 * vx / mx**4) / n
    return r, var

def compare_ratio(df, num='s', den='n'):
    a, b = df[df.group == 'A'], df[df.group == 'B']
    ra, va = delta_ratio(a[num].values, a[den].values)
    rb, vb = delta_ratio(b[num].values, b[den].values)
    diff = rb - ra; se = np.sqrt(va + vb); z = diff / se
    return dict(A=ra, B=rb, diff=diff, se=se, ci=[diff - 1.96 * se, diff + 1.96 * se],
                rel=diff / ra, p=float(2 * stats.norm.sf(abs(z))), nA=len(a), nB=len(b))

act = uu[uu.n > 0].copy()  # users who opened the form at least once
R['primary_delta'] = compare_ratio(act)

# cluster bootstrap
rng = np.random.default_rng(42)
B = 10000
boot = []
grp = {g: act[act.group == g][['s', 'n']].values for g in 'AB'}
for _ in range(B):
    r = {}
    for g in 'AB':
        arr = grp[g]; idx = rng.integers(0, len(arr), len(arr)); smp = arr[idx]
        r[g] = smp[:, 0].sum() / smp[:, 1].sum()
    boot.append(r['B'] - r['A'])
boot = np.array(boot)
R['primary_boot'] = dict(ci=[float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))],
                         p=float(2 * min((boot <= 0).mean(), (boot >= 0).mean())))
np.save('boot.npy', boot)

# naive attempt-level z-test (for comparison only)
ta = p[p.g == 'A'].r4; tb = p[p.g == 'B'].r4
pp = (ta.sum() + tb.sum()) / (len(ta) + len(tb))
se_n = np.sqrt(pp * (1 - pp) * (1 / len(ta) + 1 / len(tb)))
R['naive'] = dict(A=float(ta.mean()), B=float(tb.mean()), p=float(2 * stats.norm.sf(abs((tb.mean() - ta.mean()) / se_n))),
                  se=float(np.sqrt(ta.mean()*(1-ta.mean())/len(ta) + tb.mean()*(1-tb.mean())/len(tb))))
R['design_effect'] = float((R['primary_delta']['se'] / R['naive']['se']) ** 2)

# user-level: share of users with >=1 success
ua = (act[act.group == 'A'].s > 0); ub = (act[act.group == 'B'].s > 0)
ct = np.array([[ub.sum(), (~ub).sum()], [ua.sum(), (~ua).sum()]])
chi = stats.chi2_contingency(ct, correction=False)
se_u = np.sqrt(ua.mean()*(1-ua.mean())/len(ua) + ub.mean()*(1-ub.mean())/len(ub))
du = ub.mean() - ua.mean()
R['user_success'] = dict(A=float(ua.mean()), B=float(ub.mean()), diff=float(du), ci=[float(du - 1.96*se_u), float(du + 1.96*se_u)], p=float(chi[1]),
                         nA=int(len(ua)), nB=int(len(ub)))

# per-user conversion (mean of user rates): Welch t + Mann-Whitney
act['cr'] = act.s / act.n
ca, cb = act[act.group == 'A'].cr, act[act.group == 'B'].cr
R['user_cr'] = dict(A=float(ca.mean()), B=float(cb.mean()), welch_p=float(stats.ttest_ind(cb, ca, equal_var=False).pvalue),
                    mw_p=float(stats.mannwhitneyu(cb, ca).pvalue))

# step-wise conversion (delta method, users clustered)
steps = {}
pu = p.groupby(['user_id', 'g'])[['r1', 'r2', 'r3', 'r4']].sum().reset_index().rename(columns={'g': 'group'})
names = ['1→2 Ввёл реквизиты', '2→3 Подтвердил', '3→4 Успех']
for i, nm in enumerate(names):
    d = pu[pu[f'r{i+1}'] > 0]
    steps[nm] = compare_ratio(d, num=f'r{i+2}', den=f'r{i+1}')
R['steps'] = steps
# Holm correction across 3 steps
ps = np.array([steps[k]['p'] for k in names]); order = np.argsort(ps); holm = np.empty(3)
for rank, i in enumerate(order): holm[i] = min(1, ps[i] * (3 - rank))
holm = np.maximum.accumulate(holm[order])[np.argsort(order)]
for k, h in zip(names, holm): steps[k]['p_holm'] = float(h)

# segments
seg = {}
act['age_grp'] = pd.cut(act.age, [0, 25, 35, 45, 200], labels=['18–25', '26–35', '36–45', '46+'])
for col in ['device_type', 'city', 'age_grp']:
    for v in act[col].dropna().unique():
        seg[f'{col}={v}'] = compare_ratio(act[act[col] == v])
R['segments'] = seg
# interaction test: device (logit on attempts w/ cluster-robust SE) -> approx via difference of deltas
def interaction(col, v1, v2):
    s1, s2 = seg[f'{col}={v1}'], seg[f'{col}={v2}']
    d = s1['diff'] - s2['diff']; se = np.sqrt(s1['se']**2 + s2['se']**2)
    return dict(diff_of_diffs=d, p=float(2 * stats.norm.sf(abs(d / se))))
R['interaction_device'] = interaction('device_type', 'ios', 'android')

# time on step 2 (entering requisites): autofill should shorten it
t12 = p[p.r2 == 1].assign(t=lambda d: (d.step2_entered - d.step1_opened).dt.total_seconds() / 60)
tu = t12.groupby(['user_id', 'g']).t.mean().reset_index()
R['time_1_2'] = dict(A=float(t12[t12.g == 'A'].t.mean()), B=float(t12[t12.g == 'B'].t.mean()),
                     medA=float(t12[t12.g == 'A'].t.median()), medB=float(t12[t12.g == 'B'].t.median()),
                     mw_p_user=float(stats.mannwhitneyu(tu[tu.g == 'A'].t, tu[tu.g == 'B'].t).pvalue))
for a, b, key in [(S[1], S[2], 'time_2_3'), (S[2], S[3], 'time_3_4')]:
    t = p[p[b].notna()].assign(t=lambda d: (d[b] - d[a]).dt.total_seconds() / 60)
    R[key] = {g: float(t[t.g == g].t.mean()) for g in 'AB'}

# daily dynamics & cumulative
p['day'] = p.step1_opened.dt.day
daily = p.groupby(['day', 'g']).r4.agg(['sum', 'size']).unstack()
cum = daily.cumsum()
R['daily'] = {g: (daily['sum'][g] / daily['size'][g]).round(4).tolist() for g in 'AB'}
R['cum'] = {g: (cum['sum'][g] / cum['size'][g]).round(4).tolist() for g in 'AB'}
R['weekly'] = {}
p['week'] = pd.cut(p.day, [0, 7, 14, 21, 31], labels=['1–7', '8–14', '15–21', '22–30'])
for w, d in p.groupby('week', observed=True):
    du_ = d.groupby(['user_id', 'g']).agg(n=('r1', 'size'), s=('r4', 'sum')).reset_index().rename(columns={'g': 'group'})
    R['weekly'][str(w)] = compare_ratio(du_)

# MDE at 80% power, alpha .05 for the primary metric
se = R['primary_delta']['se']
R['mde_abs'] = float((stats.norm.ppf(.975) + stats.norm.ppf(.8)) * se)

def conv(o):
    if isinstance(o, dict): return {str(k): conv(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [conv(v) for v in o]
    if isinstance(o, (np.floating,)): return float(o)
    if isinstance(o, (np.integer,)): return int(o)
    return o
json.dump(conv(R), open('results.json', 'w'), ensure_ascii=False, indent=1)
act.to_csv('users_clean.csv', index=False); p.to_csv('payments_clean.csv', index=False)
print(json.dumps(conv(R), ensure_ascii=False, indent=1))
